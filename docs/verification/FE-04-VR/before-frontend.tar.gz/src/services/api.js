import { useEffect, useState } from 'react';

export class ApiError extends Error {
  constructor(status, code) {
    super(code);
    this.status = status;
    this.code = code;
  }
}
export async function readApi(path, { signal } = {}) {
  const base = import.meta.env.VITE_API_BASE_URL || '/api/v1';
  const response = await fetch(`${base}${path}`, {
    credentials: 'include',
    signal,
    headers: { Accept: 'application/json' },
  });
  if (response.status === 204) return null;
  let body;
  try {
    body = await response.json();
  } catch {
    throw new ApiError(response.status, 'INVALID_RESPONSE');
  }
  if (!response.ok || body.success !== true)
    throw new ApiError(response.status, body.error?.code || 'UNAVAILABLE');
  return body;
}
export function useRead(path, reload = 0) {
  const [result, setResult] = useState({
    path: null,
    reload: -1,
    status: 'loading',
  });
  useEffect(() => {
    if (!path) return;
    const controller = new AbortController();
    let active = true;
    const timeout = setTimeout(() => controller.abort(), 8000);
    readApi(path, { signal: controller.signal })
      .then((body) => {
        if (active) setResult({ path, reload, status: 'ready', body });
      })
      .catch((error) => {
        if (active) setResult({ path, reload, status: 'error', error });
      })
      .finally(() => clearTimeout(timeout));
    return () => {
      active = false;
      clearTimeout(timeout);
      controller.abort();
    };
  }, [path, reload]);
  if (!path) return { status: 'idle' };
  // A location change must never flash the previous recipe/profile while its request loads.
  return result.path === path && result.reload === reload
    ? result
    : { status: 'loading' };
}
const fields = new Set([
  'q',
  'category',
  'tag',
  'difficulty',
  'maxMinutes',
  'ingredientIds',
  'ingredientMatch',
  'page',
  'limit',
  'sort',
]);
export function searchQuery(search) {
  const params = new URLSearchParams(search);
  for (const [key] of params)
    if (!fields.has(key) || params.getAll(key).length !== 1)
      return { error: 'Bộ lọc không hợp lệ.' };
  if (
    params.has('q') &&
    (!params.get('q').trim() || params.get('q').length > 120)
  )
    return { error: 'Từ khóa cần từ 1 đến 120 ký tự.' };
  return {
    params,
    path: '/recipes' + (params.size ? '?' + params.toString() : ''),
  };
}
export function recipeHref(recipe) {
  return typeof recipe?.slug === 'string' &&
    /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(recipe.slug) &&
    recipe.slug.length <= 200
    ? '/recipes/' + recipe.slug
    : null;
}
export function profileHref(user) {
  return /^[a-fA-F0-9]{24}$/.test(user?.id || '') ? '/users/' + user.id : null;
}
