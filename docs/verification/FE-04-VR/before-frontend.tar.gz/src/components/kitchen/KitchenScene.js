import { createElement as h } from 'react';

export function KitchenScene() {
  return h(
    'div',
    { className: 'kitchen-scene', 'aria-hidden': true },
    h('div', { className: 'kitchen-wall' }),
    h('div', { className: 'sunlight' }),
    h('img', {
      className: 'kitchen-window',
      src: '/assets/kitchen/window.svg',
      alt: '',
      width: 300,
      height: 410,
    }),
    h('img', {
      className: 'kitchen-lamp lamp-left',
      src: '/assets/kitchen/lamp.svg',
      alt: '',
      width: 180,
      height: 180,
    }),
    h('img', {
      className: 'kitchen-lamp lamp-right',
      src: '/assets/kitchen/lamp.svg',
      alt: '',
      width: 180,
      height: 180,
    }),
    h('img', {
      className: 'kitchen-stove',
      src: '/assets/kitchen/stove.svg',
      alt: '',
      width: 310,
      height: 430,
    }),
    h('img', {
      className: 'kitchen-counter',
      src: '/assets/kitchen/countertop.svg',
      alt: '',
      width: 1400,
      height: 160,
    }),
  );
}
