import { createElement as h, useSyncExternalStore } from 'react';

const changed = () => window.dispatchEvent(new Event('popstate'));
export function navigate(href, { replace = false } = {}) {
  const url = new URL(href, window.location.origin);
  if (url.origin !== window.location.origin) return;
  window.history[replace ? 'replaceState' : 'pushState'](
    null,
    '',
    url.pathname + url.search + url.hash,
  );
  changed();
}
export function Link({ href, children, onClick, ...props }) {
  return h(
    'a',
    {
      ...props,
      href,
      onClick(event) {
        onClick?.(event);
        if (
          event.defaultPrevented ||
          event.button !== 0 ||
          event.metaKey ||
          event.ctrlKey ||
          event.shiftKey ||
          event.altKey ||
          props.target ||
          props.download
        )
          return;
        if (
          new URL(href, window.location.origin).origin !==
          window.location.origin
        )
          return;
        event.preventDefault();
        navigate(href);
      },
    },
    children,
  );
}
const subscribe = (callback) => {
  window.addEventListener('popstate', callback);
  return () => window.removeEventListener('popstate', callback);
};
const snapshot = () => window.location.pathname + window.location.search;
export function useLocation() {
  const location = useSyncExternalStore(subscribe, snapshot);
  const url = new URL(location, window.location.origin);
  return { pathname: url.pathname, search: url.search };
}
export function matchRoute(pathname) {
  if (pathname === '/') return { page: 'home' };
  if (pathname === '/recipes') return { page: 'explore' };
  if (pathname === '/forbidden') return { page: 'forbidden' };
  const recipe = /^\/recipes\/([a-z0-9]+(?:-[a-z0-9]+)*)$/.exec(pathname);
  if (recipe && recipe[1].length <= 200)
    return { page: 'detail', value: recipe[1] };
  const profile = /^\/users\/([a-fA-F0-9]{24})$/.exec(pathname);
  if (profile) return { page: 'profile', value: profile[1] };
  return { page: 'notfound' };
}
